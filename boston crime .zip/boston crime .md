```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
from scipy.stats import norm

from sklearn.preprocessing import scale
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from scipy import stats
from IPython.display import display, HTML


```


```python
data = pd.read_csv("C://Users//RENJITA//Downloads//crime.csv//crime.csv",encoding = "ISO-8859-1")


```

The boston dataset is being loaded into jupiter notebook with the help of panda library.


```python
data.describe
```




    <bound method NDFrame.describe of        INCIDENT_NUMBER  OFFENSE_CODE  OFFENSE_CODE_GROUP  \
    0           I182080058          2403  Disorderly Conduct   
    1           I182080053          3201       Property Lost   
    2           I182080052          2647               Other   
    3           I182080051           413  Aggravated Assault   
    4           I182080050          3122            Aircraft   
    ...                ...           ...                 ...   
    327815   I050310906-00          3125     Warrant Arrests   
    327816   I030217815-08           111            Homicide   
    327817   I030217815-08          3125     Warrant Arrests   
    327818   I010370257-00          3125     Warrant Arrests   
    327819       142052550          3125     Warrant Arrests   
    
                            OFFENSE_DESCRIPTION DISTRICT REPORTING_AREA SHOOTING  \
    0                      DISTURBING THE PEACE      E18            495      NaN   
    1                           PROPERTY - LOST      D14            795      NaN   
    2                 THREATS TO DO BODILY HARM       B2            329      NaN   
    3            ASSAULT - AGGRAVATED - BATTERY       A1             92      NaN   
    4                        AIRCRAFT INCIDENTS       A7             36      NaN   
    ...                                     ...      ...            ...      ...   
    327815                       WARRANT ARREST       D4            285      NaN   
    327816  MURDER, NON-NEGLIGIENT MANSLAUGHTER      E18            520      NaN   
    327817                       WARRANT ARREST      E18            520      NaN   
    327818                       WARRANT ARREST      E13            569      NaN   
    327819                       WARRANT ARREST       D4            903      NaN   
    
               OCCURRED_ON_DATE  YEAR  MONTH DAY_OF_WEEK  HOUR    UCR_PART  \
    0       2018-10-03 20:13:00  2018     10   Wednesday    20    Part Two   
    1       2018-08-30 20:00:00  2018      8    Thursday    20  Part Three   
    2       2018-10-03 19:20:00  2018     10   Wednesday    19    Part Two   
    3       2018-10-03 20:00:00  2018     10   Wednesday    20    Part One   
    4       2018-10-03 20:49:00  2018     10   Wednesday    20  Part Three   
    ...                     ...   ...    ...         ...   ...         ...   
    327815  2016-06-05 17:25:00  2016      6      Sunday    17  Part Three   
    327816  2015-07-09 13:38:00  2015      7    Thursday    13    Part One   
    327817  2015-07-09 13:38:00  2015      7    Thursday    13  Part Three   
    327818  2016-05-31 19:35:00  2016      5     Tuesday    19  Part Three   
    327819  2015-06-22 00:12:00  2015      6      Monday     0  Part Three   
    
                       STREET        Lat       Long                     Location  
    0            ARLINGTON ST  42.262608 -71.121186  (42.26260773, -71.12118637)  
    1              ALLSTON ST  42.352111 -71.135311  (42.35211146, -71.13531147)  
    2                DEVON ST  42.308126 -71.076930  (42.30812619, -71.07692974)  
    3            CAMBRIDGE ST  42.359454 -71.059648  (42.35945371, -71.05964817)  
    4             PRESCOTT ST  42.375258 -71.024663  (42.37525782, -71.02466343)  
    ...                   ...        ...        ...                          ...  
    327815        COVENTRY ST  42.336951 -71.085748  (42.33695098, -71.08574813)  
    327816           RIVER ST  42.255926 -71.123172  (42.25592648, -71.12317207)  
    327817           RIVER ST  42.255926 -71.123172  (42.25592648, -71.12317207)  
    327818  NEW WASHINGTON ST  42.302333 -71.111565  (42.30233307, -71.11156487)  
    327819      WASHINGTON ST  42.333839 -71.080290  (42.33383935, -71.08029038)  
    
    [327820 rows x 17 columns]>




```python

data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>INCIDENT_NUMBER</th>
      <th>OFFENSE_CODE</th>
      <th>OFFENSE_CODE_GROUP</th>
      <th>OFFENSE_DESCRIPTION</th>
      <th>DISTRICT</th>
      <th>REPORTING_AREA</th>
      <th>SHOOTING</th>
      <th>OCCURRED_ON_DATE</th>
      <th>YEAR</th>
      <th>MONTH</th>
      <th>DAY_OF_WEEK</th>
      <th>HOUR</th>
      <th>UCR_PART</th>
      <th>STREET</th>
      <th>Lat</th>
      <th>Long</th>
      <th>Location</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>I182080058</td>
      <td>2403</td>
      <td>Disorderly Conduct</td>
      <td>DISTURBING THE PEACE</td>
      <td>E18</td>
      <td>495</td>
      <td>NaN</td>
      <td>2018-10-03 20:13:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>ARLINGTON ST</td>
      <td>42.262608</td>
      <td>-71.121186</td>
      <td>(42.26260773, -71.12118637)</td>
    </tr>
    <tr>
      <td>1</td>
      <td>I182080053</td>
      <td>3201</td>
      <td>Property Lost</td>
      <td>PROPERTY - LOST</td>
      <td>D14</td>
      <td>795</td>
      <td>NaN</td>
      <td>2018-08-30 20:00:00</td>
      <td>2018</td>
      <td>8</td>
      <td>Thursday</td>
      <td>20</td>
      <td>Part Three</td>
      <td>ALLSTON ST</td>
      <td>42.352111</td>
      <td>-71.135311</td>
      <td>(42.35211146, -71.13531147)</td>
    </tr>
    <tr>
      <td>2</td>
      <td>I182080052</td>
      <td>2647</td>
      <td>Other</td>
      <td>THREATS TO DO BODILY HARM</td>
      <td>B2</td>
      <td>329</td>
      <td>NaN</td>
      <td>2018-10-03 19:20:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>19</td>
      <td>Part Two</td>
      <td>DEVON ST</td>
      <td>42.308126</td>
      <td>-71.076930</td>
      <td>(42.30812619, -71.07692974)</td>
    </tr>
    <tr>
      <td>3</td>
      <td>I182080051</td>
      <td>413</td>
      <td>Aggravated Assault</td>
      <td>ASSAULT - AGGRAVATED - BATTERY</td>
      <td>A1</td>
      <td>92</td>
      <td>NaN</td>
      <td>2018-10-03 20:00:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>20</td>
      <td>Part One</td>
      <td>CAMBRIDGE ST</td>
      <td>42.359454</td>
      <td>-71.059648</td>
      <td>(42.35945371, -71.05964817)</td>
    </tr>
    <tr>
      <td>4</td>
      <td>I182080050</td>
      <td>3122</td>
      <td>Aircraft</td>
      <td>AIRCRAFT INCIDENTS</td>
      <td>A7</td>
      <td>36</td>
      <td>NaN</td>
      <td>2018-10-03 20:49:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>20</td>
      <td>Part Three</td>
      <td>PRESCOTT ST</td>
      <td>42.375258</td>
      <td>-71.024663</td>
      <td>(42.37525782, -71.02466343)</td>
    </tr>
    <tr>
      <td>5</td>
      <td>I182080049</td>
      <td>1402</td>
      <td>Vandalism</td>
      <td>VANDALISM</td>
      <td>C11</td>
      <td>351</td>
      <td>NaN</td>
      <td>2018-10-02 20:40:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Tuesday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>DORCHESTER AVE</td>
      <td>42.299197</td>
      <td>-71.060470</td>
      <td>(42.29919694, -71.06046974)</td>
    </tr>
    <tr>
      <td>6</td>
      <td>I182080048</td>
      <td>3803</td>
      <td>Motor Vehicle Accident Response</td>
      <td>M/V ACCIDENT - PERSONAL INJURY</td>
      <td>NaN</td>
      <td></td>
      <td>NaN</td>
      <td>2018-10-03 20:16:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>20</td>
      <td>Part Three</td>
      <td>NaN</td>
      <td>42.320734</td>
      <td>-71.056764</td>
      <td>(42.32073413, -71.05676415)</td>
    </tr>
    <tr>
      <td>7</td>
      <td>I182080047</td>
      <td>3301</td>
      <td>Verbal Disputes</td>
      <td>VERBAL DISPUTE</td>
      <td>B2</td>
      <td>603</td>
      <td>NaN</td>
      <td>2018-10-03 19:32:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>19</td>
      <td>Part Three</td>
      <td>TREMONT ST</td>
      <td>42.333807</td>
      <td>-71.103778</td>
      <td>(42.33380683, -71.10377843)</td>
    </tr>
    <tr>
      <td>8</td>
      <td>I182080045</td>
      <td>802</td>
      <td>Simple Assault</td>
      <td>ASSAULT SIMPLE - BATTERY</td>
      <td>E18</td>
      <td>543</td>
      <td>NaN</td>
      <td>2018-10-03 19:27:51</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>19</td>
      <td>Part Two</td>
      <td>AVILA RD</td>
      <td>42.256145</td>
      <td>-71.128025</td>
      <td>(42.25614494, -71.12802506)</td>
    </tr>
    <tr>
      <td>9</td>
      <td>I182080044</td>
      <td>3410</td>
      <td>Towed</td>
      <td>TOWED MOTOR VEHICLE</td>
      <td>D4</td>
      <td>621</td>
      <td>NaN</td>
      <td>2018-10-03 20:00:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>20</td>
      <td>Part Three</td>
      <td>COMMONWEALTH AVE</td>
      <td>42.348866</td>
      <td>-71.089363</td>
      <td>(42.34886600, -71.08936284)</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.shape
```




    (327820, 17)




```python
data.dtypes
```




    INCIDENT_NUMBER         object
    OFFENSE_CODE             int64
    OFFENSE_CODE_GROUP      object
    OFFENSE_DESCRIPTION     object
    DISTRICT                object
    REPORTING_AREA          object
    SHOOTING                object
    OCCURRED_ON_DATE        object
    YEAR                     int64
    MONTH                    int64
    DAY_OF_WEEK             object
    HOUR                     int64
    UCR_PART                object
    STREET                  object
    Lat                    float64
    Long                   float64
    Location                object
    dtype: object




```python
#year-wise crime
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
sns.countplot(x="YEAR", data=data)
ax.set_title("No. of crimes occurred in the year")
plt.tight_layout()
plt.show()

```


![png](output_7_0.png)



```python
ax = sns.barplot(x="STREET", y="REPORTING_AREA", data = streets)
ax.set(xlabel='Crime Street', ylabel='# of Crimes reported')
ax.set_xticklabels(streets['STREET'],rotation=90)

plt.show()
```


![png](output_8_0.png)



```python
# Top 10 Offense types

streets = data.groupby([data['OFFENSE_CODE_GROUP']])['STREET'].aggregate(np.size).reset_index().sort_values('STREET', ascending = False).head(10)
streets
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>OFFENSE_CODE_GROUP</th>
      <th>STREET</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>43</td>
      <td>Motor Vehicle Accident Response</td>
      <td>38134</td>
    </tr>
    <tr>
      <td>34</td>
      <td>Larceny</td>
      <td>26670</td>
    </tr>
    <tr>
      <td>40</td>
      <td>Medical Assistance</td>
      <td>24226</td>
    </tr>
    <tr>
      <td>31</td>
      <td>Investigate Person</td>
      <td>19176</td>
    </tr>
    <tr>
      <td>46</td>
      <td>Other</td>
      <td>18612</td>
    </tr>
    <tr>
      <td>15</td>
      <td>Drug Violation</td>
      <td>17037</td>
    </tr>
    <tr>
      <td>61</td>
      <td>Simple Assault</td>
      <td>16263</td>
    </tr>
    <tr>
      <td>63</td>
      <td>Vandalism</td>
      <td>15810</td>
    </tr>
    <tr>
      <td>64</td>
      <td>Verbal Disputes</td>
      <td>13478</td>
    </tr>
    <tr>
      <td>62</td>
      <td>Towed</td>
      <td>11632</td>
    </tr>
  </tbody>
</table>
</div>




```python
#District-wise shooting occurred
shootingOccurred = data[data["SHOOTING"] == "Y"].groupby("DISTRICT").agg("SHOOTING").count().reset_index().sort_values("SHOOTING", ascending=False)
shootingOccurred
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
p = sns.barplot(x=shootingOccurred.DISTRICT, y=shootingOccurred.SHOOTING, data=shootingOccurred)
plt.tight_layout()
plt.show()
```


![png](output_10_0.png)



```python
#Top 10 most crime occurred street
df = data["STREET"].value_counts().head(10).reset_index()
fig = plt.figure(figsize=(12,12))
ax = fig.add_subplot(111)
p = sns.barplot(x=df.iloc[:,0], y=df["STREET"], data=df)#, palette="spring")
p.set_ylabel("No. of Crimes Occurred")
p.set_xlabel("Street Name")
p.set_xticklabels(p.get_xticklabels(), rotation=90)
plt.tight_layout()
plt.show()

```


![png](output_11_0.png)



```python
#No. of hours spent on each Offence by district
df = data.groupby(["DISTRICT", "OFFENSE_CODE_GROUP"])["HOUR"].sum().reset_index().sort_values("HOUR", ascending=False)
df
fig = plt.figure(figsize=(12,12))
ax = fig.add_subplot(111)
p = sns.scatterplot(x="HOUR", y="OFFENSE_CODE_GROUP", hue="DISTRICT", data=df, palette="summer")
p.set_ylabel("No. of Crimes Occurred")
p.set_xlabel("Hours")
plt.tight_layout()
plt.show()

```


![png](output_12_0.png)



```python
 #Year wise percentage rate
yrlbl = data['YEAR'].astype('category').cat.categories.tolist()
yrwisecount = data['YEAR'].value_counts()
sizes = [yrwisecount[year] for year in yrlbl]
fig1, ax1 = plt.subplots()
ax1.pie(sizes, labels=yrlbl,  autopct='%1.1f%%',shadow=True) 
ax1.axis('equal')
ax1.set_title("Year wise crime %")
plt.show()
```


![png](output_13_0.png)



```python
# Day of the week crime %
dayofwkcount = data['DAY_OF_WEEK'].value_counts()
dayofwkcount

dayofwk = data['DAY_OF_WEEK'].astype('category').cat.categories.tolist()
dayofwk

sizes = [dayofwkcount[dow] for dow in dayofwk]
fig1, ax1 = plt.subplots()
ax1.pie(sizes, labels=dayofwk,  autopct='%1.1f%%',shadow=True) 
ax1.axis('equal')
ax1.set_title("Day of week crime %")
plt.show()
```


![png](output_14_0.png)



```python
data.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>OFFENSE_CODE</th>
      <th>YEAR</th>
      <th>MONTH</th>
      <th>HOUR</th>
      <th>Lat</th>
      <th>Long</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>OFFENSE_CODE</td>
      <td>1.000000</td>
      <td>0.043738</td>
      <td>-0.013767</td>
      <td>-0.017109</td>
      <td>-0.004865</td>
      <td>0.003512</td>
    </tr>
    <tr>
      <td>YEAR</td>
      <td>0.043738</td>
      <td>1.000000</td>
      <td>-0.343858</td>
      <td>0.001224</td>
      <td>-0.015577</td>
      <td>0.015392</td>
    </tr>
    <tr>
      <td>MONTH</td>
      <td>-0.013767</td>
      <td>-0.343858</td>
      <td>1.000000</td>
      <td>0.001991</td>
      <td>-0.004583</td>
      <td>0.004693</td>
    </tr>
    <tr>
      <td>HOUR</td>
      <td>-0.017109</td>
      <td>0.001224</td>
      <td>0.001991</td>
      <td>1.000000</td>
      <td>0.007372</td>
      <td>-0.007800</td>
    </tr>
    <tr>
      <td>Lat</td>
      <td>-0.004865</td>
      <td>-0.015577</td>
      <td>-0.004583</td>
      <td>0.007372</td>
      <td>1.000000</td>
      <td>-0.999812</td>
    </tr>
    <tr>
      <td>Long</td>
      <td>0.003512</td>
      <td>0.015392</td>
      <td>0.004693</td>
      <td>-0.007800</td>
      <td>-0.999812</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.heatmap(data.corr(), vmax=1., square=False).xaxis.tick_top()

```


![png](output_16_0.png)



```python
data.groupby('MONTH').size().plot(kind="bar")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1afdf076c88>




![png](output_17_1.png)



```python
data.groupby('HOUR').size().plot(kind = 'bar')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1afdf0bfb08>




![png](output_18_1.png)



```python
sns.FacetGrid(data,hue="MONTH",size=5).map(sns.distplot,"HOUR").add_legend()
```




    <seaborn.axisgrid.FacetGrid at 0x1af804180c8>




![png](output_19_1.png)


Crime incident reports are provided by Boston Police Department (BPD) to document the
initial details surrounding an incident to which BPD offers respond. This is a dataset containing
records from the new  cirme incident report system,which includes a reduced set of feilds focused on capturing the type of
incident as well as when and where it occured. Recods starts from 2015-2018.
In the above diagrams it is seen that
   :the greatest number of crime occured is in the year of 2017.
   :Highest crime is reported in Washigton Street.
   :the top 10 crimes are 
    Motor Vehicle Accident Response, Larceny,Medical Assistance, Investigate Person, Other,
    Drug Violation, Simple Assault, Vandalism, Verbal Disputes, and Towed.
   :District B2 has the heihest crime rate whereas A15 has the lowest crime rate.
   :According to Year wise crime percentage rate  2017 shows the heighest percentage rate but it is to be noted that in the next here the 
    crime rate percentage has gone down drastically.
   :If we consider the Day of the week crime percentage rate it is to be noted that most of the crime is occuring on fridays.
   :On estimating the correlation between variables it is to be noted that latitude and logitude are heihly correlated with value 0.99.
   : A correlation matrix is also obtained for better visualization.
   :on Comparing the hour and month of the crimes it is to be noted that it is following almost the same distribution.
